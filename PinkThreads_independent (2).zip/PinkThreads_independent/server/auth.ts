// server/auth.ts
import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { db } from "./db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "dev_secret";

// Cria token e grava em cookie
function setToken(res: express.Response, payload: any) {
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
  res.cookie("token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

// Registrar
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
      return res.status(400).json({ error: "Campos obrigatórios" });

    const hash = await bcrypt.hash(password, 10);
    const existing = await db.select().from(users).where(eq(users.email, email));

    if (existing.length > 0) return res.status(400).json({ error: "Email já usado" });

    const [user] = await db
      .insert(users)
      .values({ name, email, passwordHash: hash, role: "customer" })
      .returning();

    setToken(res, { id: user.id, role: user.role });
    res.json({ user });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: "Erro no registro" });
  }
});

// Login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [user] = await db.select().from(users).where(eq(users.email, email));

    if (!user) return res.status(400).json({ error: "Usuário não encontrado" });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(400).json({ error: "Senha incorreta" });

    setToken(res, { id: user.id, role: user.role });
    res.json({ user });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: "Erro no login" });
  }
});

// Logout
router.post("/logout", (req, res) => {
  res.clearCookie("token");
  res.json({ message: "Desconectado" });
});

// Usuário logado
router.get("/user", async (req, res) => {
  try {
    const token = req.cookies?.token;
    if (!token) return res.json({ user: null });
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const [user] = await db.select().from(users).where(eq(users.id, decoded.id));
    res.json({ user: user || null });
  } catch (err) {
    res.json({ user: null });
  }
});

export default router;
