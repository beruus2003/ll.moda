// server/index.ts (modified: switched to local JWT auth, cookie parser, simple CORS)
import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import { routes } from "./routes";
import authRoutes from "./auth";

const app = express();

app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: process.env.FRONTEND_ORIGIN || "http://localhost:5173",
  credentials: true,
}));

// rotas
app.use("/api/auth", authRoutes);
app.use("/api", routes);

const port = process.env.PORT || 3000;
app.listen(port, () =>
  console.log(`Servidor rodando na porta ${port}`)
);
