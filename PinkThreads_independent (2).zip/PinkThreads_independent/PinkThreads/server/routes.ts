import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { v2 as cloudinary } from "cloudinary";
import { storage } from "./storage";
import { requireAuth, requireAdmin, optionalAuth, type AuthenticatedRequest } from "./middleware/auth";
import { insertProductSchema, insertOrderSchema } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { z } from "zod";

// Cloudinary configuration
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit per file
    files: 10, // Max 10 files per product
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Replit Auth (handles /api/login, /api/callback, /api/logout)
  await setupAuth(app);

  // Auth Routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Products Routes (Public)
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      
      // Filter only active products for non-admin users
      const isAdmin = req.session?.userId 
        ? (await storage.getUser(req.session.userId))?.role === "admin"
        : false;
      
      const filteredProducts = isAdmin 
        ? products 
        : products.filter(p => p.isActive);

      res.json(filteredProducts);
    } catch (error) {
      console.error("Get products error:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      // Check if user is admin
      const isAdmin = req.session?.userId 
        ? (await storage.getUser(req.session.userId))?.role === "admin"
        : false;

      // Only allow inactive products for admin
      if (!product.isActive && !isAdmin) {
        return res.status(404).json({ error: "Product not found" });
      }

      res.json(product);
    } catch (error) {
      console.error("Get product error:", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Products Routes (Admin Only)
  app.post(
    "/api/products",
    requireAdmin,
    upload.array("images", 10),
    async (req: AuthenticatedRequest, res) => {
      try {
        const files = req.files as Express.Multer.File[] | undefined;
        
        // Upload images to Cloudinary
        const imageUrls: string[] = [];
        if (files && files.length > 0) {
          for (const file of files) {
            try {
              // Upload to Cloudinary
              const result = await new Promise<any>((resolve, reject) => {
                cloudinary.uploader.upload_stream(
                  { 
                    folder: 'lara-moda/products',
                    resource_type: 'image'
                  },
                  (error, result) => {
                    if (error) reject(error);
                    else resolve(result);
                  }
                ).end(file.buffer);
              });
              
              imageUrls.push(result.secure_url);
            } catch (uploadError) {
              console.error("Cloudinary upload error:", uploadError);
              throw new Error("Failed to upload image to Cloudinary");
            }
          }
        }

        // Parse and validate product data
        const productData = {
          ...req.body,
          price: req.body.price,
          stock: parseInt(req.body.stock, 10),
          isActive: req.body.isActive === "true" || req.body.isActive === true,
          images: imageUrls,
          sizes: req.body.sizes ? JSON.parse(req.body.sizes) : [],
          colors: req.body.colors ? JSON.parse(req.body.colors) : [],
        };

        const validatedData = insertProductSchema.parse(productData);
        const product = await storage.createProduct(validatedData);

        res.status(201).json(product);
      } catch (error) {
        console.error("Create product error:", error);
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: "Invalid product data", details: error.errors });
        }
        res.status(500).json({ error: "Failed to create product" });
      }
    }
  );

  app.put(
    "/api/products/:id",
    requireAdmin,
    upload.array("images", 10),
    async (req: AuthenticatedRequest, res) => {
      try {
        const files = req.files as Express.Multer.File[] | undefined;
        
        // Get existing product
        const existingProduct = await storage.getProduct(req.params.id);
        if (!existingProduct) {
          return res.status(404).json({ error: "Product not found" });
        }

        // Handle images: combine existing + new uploads
        let images = existingProduct.images || [];
        
        // If new files uploaded, convert to base64
        if (files && files.length > 0) {
          const newImageDataUrls: string[] = [];
          for (const file of files) {
            const base64 = file.buffer.toString("base64");
            const dataUrl = `data:${file.mimetype};base64,${base64}`;
            newImageDataUrls.push(dataUrl);
          }
          // Replace or append based on request
          images = req.body.replaceImages === "true" 
            ? newImageDataUrls 
            : [...images, ...newImageDataUrls];
        } else if (req.body.images) {
          // If images sent as JSON (for reordering/deletion)
          images = JSON.parse(req.body.images);
        }

        // Parse and validate update data
        const updateData: any = {};
        if (req.body.name) updateData.name = req.body.name;
        if (req.body.description) updateData.description = req.body.description;
        if (req.body.price) updateData.price = req.body.price;
        if (req.body.category) updateData.category = req.body.category;
        if (req.body.stock !== undefined) updateData.stock = parseInt(req.body.stock, 10);
        if (req.body.isActive !== undefined) {
          updateData.isActive = req.body.isActive === "true" || req.body.isActive === true;
        }
        if (req.body.sizes) updateData.sizes = JSON.parse(req.body.sizes);
        if (req.body.colors) updateData.colors = JSON.parse(req.body.colors);
        updateData.images = images;

        const product = await storage.updateProduct(req.params.id, updateData);
        
        if (!product) {
          return res.status(404).json({ error: "Product not found" });
        }

        res.json(product);
      } catch (error) {
        console.error("Update product error:", error);
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: "Invalid product data", details: error.errors });
        }
        res.status(500).json({ error: "Failed to update product" });
      }
    }
  );

  app.delete("/api/products/:id", requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      await storage.deleteProduct(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete product error:", error);
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // Orders Routes
  app.get("/api/orders", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      // Admin can see all orders, customers see only their own
      const orders = req.user.role === "admin"
        ? await storage.getAllOrders()
        : await storage.getUserOrders(req.user.id);

      res.json(orders);
    } catch (error) {
      console.error("Get orders error:", error);
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const order = await storage.getOrder(req.params.id);
      
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      // Users can only see their own orders unless admin
      if (order.userId !== req.user.id && req.user.role !== "admin") {
        return res.status(403).json({ error: "Forbidden" });
      }

      res.json(order);
    } catch (error) {
      console.error("Get order error:", error);
      res.status(500).json({ error: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const orderData = {
        ...req.body,
        userId: req.user.id,
        status: "pending",
      };

      const validatedData = insertOrderSchema.parse(orderData);
      const order = await storage.createOrder(validatedData);

      res.status(201).json(order);
    } catch (error) {
      console.error("Create order error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid order data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.patch("/api/orders/:id/status", requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }

      const order = await storage.updateOrderStatus(req.params.id, status);
      
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      res.json(order);
    } catch (error) {
      console.error("Update order status error:", error);
      res.status(500).json({ error: "Failed to update order status" });
    }
  });

  // Admin Stats
  app.get("/api/admin/stats", requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Get admin stats error:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
