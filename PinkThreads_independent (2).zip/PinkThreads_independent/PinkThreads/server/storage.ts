import { eq, and, desc, sql } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  products,
  orders,
  sessions,
  type User,
  type UpsertUser,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Products
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<void>;

  // Orders
  getAllOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  getUserOrders(userId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;

  // Admin Stats
  getAdminStats(): Promise<{
    totalProducts: number;
    activeProducts: number;
    totalOrders: number;
    pendingOrders: number;
    totalRevenue: number;
  }>;

  // Session
  upsertSession(sessionData: { sid: string; sess: any; expire: Date }): Promise<void>;
  getSession(sid: string): Promise<{ sid: string; sess: any; expire: Date } | undefined>;
  destroySession(sid: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: UpsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async upsertUser(insertUser: UpsertUser): Promise<User> {
    if (insertUser.email) {
      const existing = await this.getUserByEmail(insertUser.email);
      if (existing) {
        const result = await db
          .update(users)
          .set({
            firstName: insertUser.firstName,
            lastName: insertUser.lastName,
            profileImageUrl: insertUser.profileImageUrl,
          })
          .where(eq(users.id, existing.id))
          .returning();
        return result[0];
      }
    }
    return this.createUser(insertUser);
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return db.select().from(products).orderBy(desc(products.createdAt));
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return result[0];
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(insertProduct).returning();
    return result[0];
  }

  async updateProduct(id: string, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const result = await db
      .update(products)
      .set(updateData)
      .where(eq(products.id, id))
      .returning();
    return result[0];
  }

  async deleteProduct(id: string): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Orders
  async getAllOrders(): Promise<Order[]> {
    return db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    return result[0];
  }

  async getUserOrders(userId: string): Promise<Order[]> {
    return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const result = await db.insert(orders).values(insertOrder).returning();
    return result[0];
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const result = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    return result[0];
  }

  // Admin Stats
  async getAdminStats(): Promise<{
    totalProducts: number;
    activeProducts: number;
    totalOrders: number;
    pendingOrders: number;
    totalRevenue: number;
  }> {
    const productsCount = await db.select({ count: sql<number>`count(*)::int` }).from(products);
    const activeProductsCount = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(products)
      .where(eq(products.isActive, true));
    
    const ordersCount = await db.select({ count: sql<number>`count(*)::int` }).from(orders);
    const pendingOrdersCount = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, "pending"));
    
    const revenueResult = await db
      .select({ total: sql<string>`COALESCE(SUM(CAST(total AS DECIMAL)), 0)` })
      .from(orders)
      .where(sql`status != 'cancelled'`);

    return {
      totalProducts: productsCount[0]?.count || 0,
      activeProducts: activeProductsCount[0]?.count || 0,
      totalOrders: ordersCount[0]?.count || 0,
      pendingOrders: pendingOrdersCount[0]?.count || 0,
      totalRevenue: parseFloat(revenueResult[0]?.total || "0"),
    };
  }

  // Session
  async upsertSession(sessionData: { sid: string; sess: any; expire: Date }): Promise<void> {
    await db
      .insert(sessions)
      .values(sessionData)
      .onConflictDoUpdate({
        target: sessions.sid,
        set: {
          sess: sessionData.sess,
          expire: sessionData.expire,
        },
      });
  }

  async getSession(sid: string): Promise<{ sid: string; sess: any; expire: Date } | undefined> {
    const result = await db.select().from(sessions).where(eq(sessions.sid, sid)).limit(1);
    return result[0];
  }

  async destroySession(sid: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.sid, sid));
  }
}

export const storage = new DatabaseStorage();
