
### Alterações realizadas automaticamente
- Adicionado `server/auth.ts` com endpoints: /api/auth/register, /login, /logout, /user
- Adicionado middleware JWT em `server/middleware/auth.ts`
- Atualizado `server/index.ts` para usar cookie-parser e rotas locais
- Simplificado Cloudinary em `server/storage.ts` (usa CLOUDINARY_URL)
- Adicionado `.env.example`

Por favor revise os arquivos e adapte imports/paths conforme seu projeto local.
